
#pragma once
#include <switch.h>

namespace pu::util
{
    bool IsAtmosphere();
    bool IsReiNX();
}